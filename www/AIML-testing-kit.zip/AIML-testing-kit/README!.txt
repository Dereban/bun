Things you will need to test this code out:

1. A python IDE. I use Spyder, but IDLE works just as well.
2. The installation of the aiml library. (Note: aiml is not supported by python3)

To use this test kit:

1. Extract this folder
2. Modify the AIML file as needed.
3. Modify the Runtext.py to include the catergory you are testing.
4. Run the Runtest.py in your python IDE.