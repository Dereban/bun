# -*- coding: utf-8 -*-
"""
Created on Thu Aug 11 02:50:43 2016

@author: root
"""
import AIMLreply
message = "toki"
bot_response = AIMLreply.reply(message)
print bot_response