# -*- coding: utf-8 -*-
"""
Created on Thu Aug 11 00:26:18 2016

@author: root
"""



import aiml
import os
def reply(text):
        kernal =  aiml.Kernel()
        if os.path.isfile("BUNI_brain.brn"):
            kernal.bootstrap(brainFile = "BUNI_brain.brn")
        else:
            kernal.bootstrap(learnFiles = "std-startup.xml", commands = "load aiml b")
            kernal.saveBrain("BUNI_brain.brn")
        data = kernal.respond(text)
        print data
        return data